#!/usr/bin/env python
import os

def main():
    os.system('python tests/test_parameter.py')
    os.system('python tests/test_polynomial.py')
    os.system('python tests/test_integrals.py')
    os.system('python tests/test_qr.py')
    os.system('python tests/test_equadI.py')
    os.system('python tests/test_indexset.py')


main()

