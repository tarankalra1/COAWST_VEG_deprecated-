function [z]=z_value2(zeta,h,N,tstart,tend)
 
%zeta=ncread(his_file,'zeta'); 
%h=ncread(his_file,'h') ; 
%ocean_time_his=ncread(his_file,'ocean_time');
  
Vtransform=1; Vstretching =1; theta_s=0.0; theta_b=0.0;
hc=0.0; igrid=5 ;
% 
 report=0; 

for t=tstart:tend  
  z(:,:,:,t)=set_depth(Vtransform, Vstretching, ...
                       theta_s, theta_b, hc, N, ...
                       igrid, h, squeeze(zeta(:,:,t)), report);
end


% Interpolate the values of z from history file to be equal to average files
% for t=1:ntime*2-1
%     t1=mod(t,2);
%     if (t1==0); % if even value take average 
%       z_new(:,:,:,t)=(z(:,:,:,(t/2))+z(:,:,:,((t)/2+1)))*0.5 ;
%     else
%       z_new(:,:,:,t)=z(:,:,:,((t+1)/2)) ;
%     end
% end 

 