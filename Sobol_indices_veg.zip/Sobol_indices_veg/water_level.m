clc       ; % clear command window 
clear all ; % clear all workspace
close all ; % 

%%
%**********GRID READING**************************************************** 
url='/media/gadar/DATADRIVE1/sensitivity_history/veg_test_his_1.nc';
netcdf_load(url) ; 

imin=41; imax=50; 
jmid=50; 
% 
%lon_rho=ncread(url,'lon_rho');
% lat_rho=ncread(url,'lat_rho');
% x_rho=ncread(url,'x_rho');
% y_rho=ncread(url,'y_rho');

%h=ncread(url,'h'); 
 ot=ocean_time/(3600*24);
 igrid=5 ;
 N=10; 
 tot_t=size(ot,1)  
 
 report=0;
 
  
tstart=186;
tend=258; 

%for t=1:tot_t  
%  zeta2d(t)=zeta(t,:,:)
%  z(t,:,:,:)=set_depth(Vtransform, Vstretching, ...
%                       theta_s, theta_b, hc, N, ...
%                       igrid, h, squeeze(zeta2d(t)), report);
%end
for t=1:tot_t
    z(:,:,:,t)=set_depth(Vtransform, Vstretching, ...
                         theta_s, theta_b, hc, N, ...
                         igrid, h, squeeze(zeta(:,:,t)), report);
end
 for t=1:tot_t
     plot(t,zeta(46,56,t),'r*')
     hold on
 end
%  
% % data1=datestr(ot); % 7958 th index corresponds to the 10th July and 8028 th is the last index  
% %   
%  index_start=5000 ; 
%  iplane= 220; % this iplane corresponds to -74.03
%  jplane= 200; % this jplane corresponds to 40.33 
%  %lon_rho=ncread(url,'lon_rho',[1 1],[Inf Inf]) ;
%  for t=1:2664
%   zeta(t)=ncread(url,'zeta',[iplane jplane t],[1 1 1]);
%   days(t)=t/24 ; 
%  end 
%  plot(days,zeta,'k')
%  xlabel('time in days')
%  ylabel('free surface water level')
%  title('water level at lon=-74.03 and lat=40.33')
%  %zeta=ncread(url,'zeta',[1 1 index_start],[Inf Inf 1]);
% %                               index_start             stride=1
% %salt_var=ncread(url,'dye_03',[1 1 1 index_start],[Inf Inf Inf 11]);
% 
% %masking=ncread(url,'mask_rho');
% %[imax,jmax,kmax,total_time] = size(salt_var) 